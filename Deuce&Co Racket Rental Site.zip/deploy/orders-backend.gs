/**
 * Deuce & Co. — order book backend
 * Paste this into Apps Script (Extensions → Apps Script) on your orders sheet,
 * then deploy as a Web App with access set to "Anyone".
 * Full instructions: ORDERS-SETUP.md
 */

var HEADERS = [
  'code', 'placed', 'status', 'name', 'phone', 'email',
  'items', 'total', 'startKey', 'days', 'venueId',
  'hours', 'lights', 'slot', 'zoneId', 'address', 'channel', 'itemsJson'
];

function sheet_() {
  var sh = SpreadsheetApp.getActiveSpreadsheet().getSheets()[0];
  if (sh.getLastRow() === 0) {
    sh.appendRow(HEADERS);
    sh.setFrozenRows(1);
  }
  return sh;
}

/** GET — the website reads the order book */
function doGet() {
  var sh = sheet_();
  var values = sh.getDataRange().getValues();
  var head = values.shift() || [];
  var out = values.filter(function (r) { return r[0]; }).map(function (r) {
    var o = {};
    head.forEach(function (k, i) { o[k] = r[i]; });
    o.days = Number(o.days) || 1;
    o.hours = Number(o.hours) || 0;
    o.total = Number(o.total) || 0;
    o.slot = o.slot === '' || o.slot === null ? null : Number(o.slot);
    o.lights = o.lights === true || o.lights === 'TRUE' || o.lights === 'true';
    try { o.items = JSON.parse(o.itemsJson || '[]'); } catch (e) { o.items = []; }
    return o;
  });
  // newest first, matching the dashboard
  out.reverse();
  return json_(out);
}

/** POST — the website creates a booking or updates a status */
function doPost(e) {
  var body = {};
  try { body = JSON.parse(e.postData.contents); } catch (err) { return json_({ ok: false }); }
  var sh = sheet_();

  if (body.action === 'status') {
    var codes = sh.getRange(2, 1, Math.max(sh.getLastRow() - 1, 1), 1).getValues();
    for (var i = 0; i < codes.length; i++) {
      if (String(codes[i][0]) === String(body.code)) {
        sh.getRange(i + 2, HEADERS.indexOf('status') + 1).setValue(body.status);
        return json_({ ok: true });
      }
    }
    return json_({ ok: false, reason: 'code not found' });
  }

  // create
  var row = HEADERS.map(function (k) {
    var v = body[k];
    if (k === 'placed') return Utilities.formatDate(new Date(), 'Asia/Manila', 'd MMM yyyy h:mm a');
    if (v === undefined || v === null) return '';
    return v;
  });
  sh.appendRow(row);
  notify_(body);
  return json_({ ok: true, code: body.code });
}

/**
 * Optional: email yourself on every new booking.
 * Put your address in TO and uncomment the MailApp line.
 */
function notify_(o) {
  var TO = '';
  if (!TO) return;
  // MailApp.sendEmail(TO, 'New Deuce & Co. booking ' + o.code,
  //   [o.code, o.name, o.phone, o.email, o.items, 'Total: ' + o.total].join('\n'));
}

function json_(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
